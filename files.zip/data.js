// ✏️ EDIT ONLY THIS FILE to customise your portfolio.
const DATA = {
  name: "Your Name",
  tagline: "I build AI products that ship.",
  bio: "AI engineer who builds LLM applications end to end: a RAG chatbot that qualifies leads in production, an agent that automates a repetitive workflow, and a web app used by real customers.",
  avatar: "", // path or URL to your photo, e.g. "assets/me.jpg". Leave empty for a placeholder.
  location: "City, Country",
  resume: "resume.pdf", // put your PDF next to index.html. Typing "resume" anywhere opens it.

  // Floating pill nav (icons: home, work, code, trophy, list, user)
  nav: [
    { icon: "home",   href: "#home",       label: "Home" },
    { icon: "work",   href: "#experience", label: "Experience" },
    { icon: "code",   href: "#projects",   label: "Projects" },
    { icon: "trophy", href: "#wins",       label: "Achievements" },
    { icon: "list",   href: "#skills",     label: "Skills" }
  ],
  // Icons: github, x, linkedin, mail
  socials: [
    { icon: "github",   href: "https://github.com/yourname",      label: "GitHub" },
    { icon: "x",        href: "https://x.com/yourname",           label: "X" },
    { icon: "linkedin", href: "https://linkedin.com/in/yourname", label: "LinkedIn" },
    { icon: "mail",     href: "mailto:you@example.com",           label: "Email" }
  ],

  stats: [
    { value: "3",   label: "hackathon wins" },
    { value: "$1K+", label: "in prizes" },
    { value: "2",   label: "live products" },
    { value: "50+", label: "active users" }
  ],

  experience: [
    {
      role: "AI Engineer", org: "Company Name", orgLink: "https://example.com", orgLabel: "example.com",
      period: "Jan 2026 – Present", place: "Remote",
      bullets: [
        "Built and deployed a LangChain/LangGraph agent that answers inbound questions and qualifies leads with no human in the loop.",
        "Built the RAG pipeline: embeddings in a vector database, an LLM for grounded answers, Supabase for lead storage.",
        "Shipped a booking platform in 8 days with real-time availability checks and role-based admin."
      ],
      tags: ["Python", "FastAPI", "LangGraph", "Pinecone", "Supabase", "Next.js", "TypeScript"]
    },
    {
      role: "B.Tech in Computer Science", org: "Your University",
      period: "2023 – 2027", place: "Final year · expected"
    }
  ],

  projects: [
    { name: "Project One",   desc: "What it does and who uses it, in one or two sentences.", tags: ["Python", "LangGraph"],  link: "https://github.com/yourname/project-one" },
    { name: "Project Two",   desc: "A short description of the problem you solved.",          tags: ["Next.js", "Supabase"],  link: "https://github.com/yourname/project-two" },
    { name: "Project Three", desc: "Another project with a live demo or repo link.",          tags: ["FastAPI", "Pinecone"],  link: "https://github.com/yourname/project-three" }
  ],

  achievements: [
    { title: "1st place – Hackathon Name",  desc: "Built an AI agent that does X. Won $500." },
    { title: "Finalist – Another Hackathon", desc: "Short one-line description." }
  ],

  skills: ["Python", "TypeScript", "LangGraph", "RAG", "FastAPI", "Next.js", "PostgreSQL", "Docker"],

  contact: {
    heading: "Let's work together",
    text: "Open to AI engineering roles and internships, freelance builds, and hackathon collabs. Best reached via X DM or email.",
    buttons: [
      { label: "DM on X",       icon: "x",    href: "https://x.com/yourname" },
      { label: "Send an Email", icon: "mail", href: "mailto:you@example.com", primary: true }
    ]
  }
};
